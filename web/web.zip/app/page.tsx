import { LandingHero, FeatureGrid, AboutCTA, ContactSection } from "@/components/LandingSections";

export default function HomePage() {
  return (
    <>
      <LandingHero />
      <FeatureGrid />
      <AboutCTA />
      <ContactSection />
    </>
  );
}